{
  "offlineBasemaps": null,
  "templatePath": null,
  "views": [
    {
      "expandedShells": true,
      "name": "IWantToMenuSectionView"
    },
    {
      "expandedShells": false,
      "name": "LookAndFeelSectionView"
    },
    {
      "expandedShells": false,
      "name": "ApplicationSectionView"
    },
    {
      "expandedShells": true,
      "name": "AccessibilitySectionView"
    },
    {
      "expandedShells": false,
      "name": "OfflineSectionView"
    },
    {
      "expandedShells": true,
      "name": "GeolocateSectionView"
    },
    {
      "expandedShells": false,
      "name": "HomePanelSectionView"
    },
    {
      "expandedShells": true,
      "name": "ToolbarSectionView"
    },
    {
      "expandedShells": true,
      "name": "ToolBehaviorSectionView"
    },
    {
      "expandedShells": false,
      "name": "InstantSearchSectionView"
    },
    {
      "expandedShells": false,
      "name": "LayerListSectionView"
    },
    {
      "expandedShells": false,
      "name": "PushpinsSectionView"
    },
    {
      "expandedShells": false,
      "name": "OptimizerIntegrationSectionView"
    },
    {
      "expandedShells": true,
      "name": "MapWidgetsSectionView"
    },
    {
      "expandedShells": false,
      "name": "MapSectionView"
    },
    {
      "expandedShells": false,
      "name": "InsightIntegrationSectionView"
    }
  ]
}